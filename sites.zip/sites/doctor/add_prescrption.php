<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/doctor_portal.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Untitled Document</title>
<link href="../form_table.css" rel="stylesheet" type="text/css" />
<!-- InstanceEndEditable -->
<style type="text/css">
#t_container {
	height: 685px;
	width: 100%;
	margin-top: -9px;
	margin-right: -9px;
	margin-bottom: -9px;
	margin-left: -9px;
}
#t_container #upper {
	width: 102%;
	height: 80px;
	background-color: #52D3AD;
	margin-top: 0px;
	color: #000000;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-weight: 600;
	text-transform: uppercase;
	text-align: center;
	text-shadow: 0px 0px;
	letter-spacing: 5px;
	word-spacing: 8px;
}
#t_container #main_content {
	width: 100%;
	height: 530px;
	float: left;
}
#t_container #main_content #left_menuside {
	width: 20%;
	float: left;
	height: 400px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	padding: 0px;
	margin-left: 0px;
	background-color: #56D9BF;
}
#main_content #left_menuside ul {
	padding: 0px;
	margin: 0px;
	width: 100%;
}
#left_menuside ul li {
	list-style: none;
	background-color: #8AD3BD;
	text-indent: 6px;
	border: 1px solid #EAEDEC;
	width: 100%;
	height: 48px;
}
#left_menuside ul li a {
	text-decoration: none;
	color: #050505;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	text-transform: uppercase;
	width: 193px;
	height: 54px;
	display: block;
	text-align: center;
	line-height: 45px;
}
#left_menuside ul li:hover ul {
	visibility: visible;
	top: 31px;
}
#left_menuside ul li a:hover {
	color: #D5D0AF;
}
#t_container #main_content #right_content {
	width: 75%;
	height: 400px;
	float: left;
}

#t_container #lower {
	clear: both;
	width: 100%;
	height: 60px;
	text-align: center;
	color: #000000;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-style: normal;
	font-weight: 600;
}
</style>

<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->

</head>

<body>
<div id="t_container">
  <header id="upper"><br />
    <!-- InstanceBeginEditable name="edit_text" -->
    <h3>welcome to doctor portal</h3>
  <!-- InstanceEndEditable --></header>
  <main id="main_content"><aside id="left_menuside"><!-- InstanceBeginEditable name="Edit_menu" -->
    <ul>
      <li><a href="#">appointment</a></li>
      <li><a href="#">see reports </a></li>
      <li><a href="#"> add prescription</a></li>
      <li><a href="#">view blood bank</a></li>
    </ul>
  <!-- InstanceEndEditable --></aside>
    <!-- InstanceBeginEditable name="Edit_doctor_cont" -->
    <aside id="right_content"><form><table width="704" height="308" border="0" summary="prescription">
  <caption>
    give prescription!!<br /><hr width="350" />
  </caption>
  <tbody>
    <tr>
      <th width="325" height="34" scope="col"><label>patient name</label></th>
      <th width="369" scope="col">
        <input type="text" name="textfield" id="textfield" /></th>
    </tr>
    <tr>
      <td height="25"><label>patient id</label></td>
      <td>
        <input type="number" name="number" id="number" /></td>
    </tr>
    <tr>
      <td height="35"><label>gender</label></td>
      <td><p>
        <label>
          <input name="RadioGroup1" type="radio"  id="RadioGroup1_0" value="0" />
          male</label>
        <label>
          <input name="RadioGroup1" type="radio"  id="RadioGroup1_1" value="1" />
          female</label>
        <br />
      </p></td>
    </tr>
    <tr>
      <td height="26"><label>age</label></td>
      <td>
        <input type="number" name="number2" id="number2" /></td>
    </tr>
    <tr>
      <td height="36"><label>address</label></td>
      <td><input type="text" /></td>
    </tr>
    <tr>
      <td height="49"><label>symptoms</label></td>
      <td><textarea></textarea></td>
    </tr>
    <tr>
      <td><label>medicines</label></td>
      <td><textarea></textarea></td>
    </tr>
    <tr>
      <td height="24"></td>
      <td><input type="submit" id="submit" /></td>
    </tr>
  </tbody>
</table></form>
</aside>
    <!-- InstanceEndEditable --></main>
  <footer id="lower">For any help -contact to admin at 8969420647<br />
    All rights reserved @ admin 
  </footer>
</div>


</body>
<!-- InstanceEnd --></html>
