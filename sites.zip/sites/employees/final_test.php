<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">
#navbar {
	padding: 0px;
	width: 20%;
	height: 400px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
	background-color: #56D9BF;
}
#navbar ul {
	margin: 0px;
	padding: 0px;
	width: 100%;
}
#navbar ul li {
	list-style: none;
	background-color: #8AD3BD;
	text-indent: 50px;
	text-align: left;
	border: 1px solid #EAEDEC;
	width: 100%;
	height: 47px;
}
#navbar ul li a {
	text-decoration: none;
	color: #050505;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	text-transform: uppercase;
	width: 110px;
	height: 40px;
	display: block;
	text-align: center;
	line-height: 45px;
}

#navbar ul li:hover ul {
	visibility: visible;
	top: 31px;
	
}
#navbar ul li a:hover {
	color: #D5D0AF;
}

</style>
</head>

<body>
<nav id="navbar">
  <ul>
    <li><a href="#">home </a>
    </li>
    <li><a href="#">home </a>
    </li>
    <li><a href="#">home </a>
    </li>
    <li><a href="#">home </a>
    </li>
  </ul>
</nav>
</body>
</html>