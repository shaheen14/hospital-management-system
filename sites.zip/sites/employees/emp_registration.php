<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="../jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css" />
<link href="../jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css" />
<link href="../jQueryAssets/jquery.ui.tabs.min.css" rel="stylesheet" type="text/css" />
<link href="e_logincss.css" rel="stylesheet" type="text/css" />
<link href="../form_table.css" rel="stylesheet" type="text/css" />
<script src="../jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="../jQueryAssets/jquery-ui-1.9.2.tabs.custom.min.js" type="text/javascript"></script>
</head>
<style type="text/css">
#empreg_container {
	height: 580px;
	width: 100%;
	margin-top: -9px;
	margin-right: -9px;
	margin-bottom: -9px;
	margin-left: -9px;
}
#empreg_container #upper_part {
	width: 102%;
	height: 80px;
	background-color: #52D3AD;
	margin-top: 0px;
	color: #000000;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-weight: 600;
	text-transform: uppercase;
	text-align: center;
	text-shadow: 0px 0px;
	letter-spacing: 5px;
	word-spacing: 8px;
}
#empreg_container #Tabs1 {
	width: 100%;
	height: 490px;
	margin-top: 8px;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-size: 16px;
	color: #000000;
	border-style: hidden;
	margin-left: auto;
	margin-right: auto;
}
#empreg_container #Tabs1 ul {
	width: 80%;
}
#empreg_container #Tabs1 ul li {
	width: 160px;
}
</style>

<body><div id="empreg_container">
<header id="upper_part"><br> <h3>welcome to Employees portal</h3></header>
<div id="Tabs1">
  <ul>
    <li><a href="#tabs-1">doctor</a></li>
    <li><a href="#tabs-2">Nurse</a></li>
    <li><a href="#tabs-3">Accountant</a></li>
    <li><a href="#tabs-4">Pharmasist</a></li>
    <li><a href="#tabs-5">Laboratorist</a></li>
    <li><a href="#tabs-6">Admin</a></li>
</ul>
  <div id="tabs-1">
    <form>
      <fieldset>
        <legend>Welcome doctor</legend>
        <table width="406" height="183">
          <tbody>
            <tr>
              <td height="31">doctor id</td>
              <td>
                <input type="text" name="textfield2" id="textfield2" /></td>
            </tr>
            <tr>
              <td width="170" height="36"><label>Name:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34"><label>email id</label>
                &nbsp;</td>
              <td><input type="email" /></td>
            </tr>
            <tr>
              <td height="34"><label> desired Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34">&nbsp;</td>
              <td><input type="submit" id="submit" />
               </td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-2">
   <form>
      <fieldset>
        <legend>Welcome nurse</legend>
        <table width="406" height="183">
          <tbody>
            <tr>
              <td height="31">nurse id</td>
              <td>
                <input type="text" name="textfield2" id="textfield2" /></td>
            </tr>
            <tr>
              <td width="170" height="36"><label>Name:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34"><label>email id</label>
                &nbsp;</td>
              <td><input type="email" /></td>
            </tr>
            <tr>
              <td height="34"><label> desired Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34">&nbsp;</td>
              <td><input type="submit" id="submit" />
                </td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-3">
    <form>
      <fieldset>
        <legend>Welcome accountant</legend>
        <table width="406" height="168">
          <tbody>
            <tr>
              <td height="30">accountant id</td>
              <td>
                <input type="text" name="textfield2" id="textfield2" /></td>
            </tr>
            <tr>
              <td width="169" height="30"><label>Name:</label></td>
              <td width="225"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="30"><label>email id</label>
                &nbsp;</td>
              <td><input type="email" /></td>
            </tr>
            <tr>
              <td height="30"><label> desired Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34">&nbsp;</td>
              <td><input type="submit" id="submit" value="submit" />
             
                </td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-4">
    <form>
      <fieldset>
        <legend>Welcome pharmacist</legend>
        <table width="406" height="183">
          <tbody>
            <tr>
              <td height="31">pharmacist id</td>
              <td>
                <input type="text" name="textfield2" id="textfield2" /></td>
            </tr>
            <tr>
              <td width="170" height="36"><label>Name:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34"><label>email id</label>
                &nbsp;</td>
              <td><input type="email" /></td>
            </tr>
            <tr>
              <td height="34"><label> desired Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34">&nbsp;</td>
              <td><input type="submit" id="submit" value="submit" />
                </td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-5">
    <form>
      <fieldset>
        <legend>Welcome laboratorist</legend>
        <table width="406" height="183">
          <tbody>
            <tr>
              <td height="31">laboratorist id</td>
              <td>
                <input type="text" name="textfield2" id="textfield2" /></td>
            </tr>
            <tr>
              <td width="170" height="36"><label>Name:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34"><label>email id</label>
                &nbsp;</td>
              <td><input type="email" /></td>
            </tr>
            <tr>
              <td height="34"><label> desired Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34">&nbsp;</td>
              <td><input type="submit" id="submit" value="submit" />
                </td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-6">
   <form>
      <fieldset>
        <legend>Welcome admin</legend>
        <table width="406" height="183">
          <tbody>
            <tr>
              <td height="31">admin id</td>
              <td>
                <input type="text" name="textfield2" id="textfield2" /></td>
            </tr>
            <tr>
              <td width="170" height="36"><label>Name:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34"><label>email id</label>
                &nbsp;</td>
              <td><input type="email" /></td>
            </tr>
            <tr>
              <td height="34"><label> desired Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="34">&nbsp;</td>
              <td><input type="submit" id="submit" value="submit" />
               </td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
</div>
</div>
<script type="text/javascript">
$(function() {
	$( "#Tabs1" ).tabs(); 
});
</script>
</body>
</html>