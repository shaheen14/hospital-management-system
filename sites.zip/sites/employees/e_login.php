<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="../jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css" />
<link href="../jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css" />
<link href="../jQueryAssets/jquery.ui.tabs.min.css" rel="stylesheet" type="text/css" />
<link href="e_logincss.css" rel="stylesheet" type="text/css" />
<script src="../jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="../jQueryAssets/jquery-ui-1.9.2.tabs.custom.min.js" type="text/javascript"></script>
</head>
<style type="text/css">
#s_container {
	height: 580px;
	width: 100%;
	margin-top: -9px;
	margin-right: -9px;
	margin-bottom: -9px;
	margin-left: -9px;
}
#s_container #upper_part {
	width: 102%;
	height: 80px;
	background-color: #52D3AD;
	margin-top: 0px;
	color: #000000;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-weight: 600;
	text-transform: uppercase;
	text-align: center;
	text-shadow: 0px 0px;
	letter-spacing: 5px;
	word-spacing: 8px;
}
#s_container #Tabs1 {
	width: 100%;
	height: 490px;
	margin-top: 8px;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-size: 16px;
	color: #000000;
	border-style: hidden;
	margin-right: auto;
	margin-left: auto;
}
#s_container #Tabs1 ul {
	width: 80%;
}
#s_container #Tabs1 ul li {
	width: 160px;
}
</style>

<body><div id="s_container">
<header id="upper_part"><br> <h3>welcome to Employees portal</h3></header>
<div id="Tabs1">
  <ul>
    <li><a href="#tabs-5">doctor</a></li>
    <li><a href="#tabs-1">Nurse</a></li>
    <li><a href="#tabs-2">Accountant</a></li>
    <li><a href="#tabs-3">Pharmasist</a></li>
    <li><a href="#tabs-4">Laboratorist</a></li>
    <li><a href="#tabs-6">Admin</a></li>
</ul>
  <div id="tabs-5">
    <form>
      <fieldset>
        <legend>Welcome doctor</legend>
        <table width="406" height="238">
          <tbody>
            <tr>
              <td width="170" height="68"><label>doctor id:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="29"><label>Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="122">&nbsp;</td>
              <td><input type="submit" />
                <br />
                <p style="text-align: centre;">New to online sevices??</p>
                <p style="font-size: 16px; text-align: centre;"><a href="#">Create A New Account</a></p></td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-1">
    <form>
      <fieldset>
        <legend>Welcome Nurse</legend>
        <table width="406" height="238">
          <tbody>
            <tr>
              <td width="170" height="68"><label>Nurse id:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="29"><label>Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="122">&nbsp;</td>
              <td><input type="submit" />
                <br />
                <p style="text-align: centre;">New to online sevices??</p>
                <p style="font-size: 16px; text-align: centre;"><a href="#">Create A New Account</a></p></td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-2">
    <form>
      <fieldset>
        <legend>Welcome Accountant</legend>
        <table width="406" height="238">
          <tbody>
            <tr>
              <td width="170" height="68"><label>accountant id:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="29"><label>Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="122">&nbsp;</td>
              <td><input type="submit" />
                <br />
                <p style="text-align: centre;">New to online sevices??</p>
                <p style="font-size: 16px; text-align: centre;"><a href="#">Create A New Account</a></p></td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-3">
    <form>
      <fieldset>
        <legend>Welcome Pharmacist</legend>
        <table width="406" height="238">
          <tbody>
            <tr>
              <td width="170" height="68"><label>pharmacist id:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="29"><label>Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="122">&nbsp;</td>
              <td><input type="submit" />
                <br />
                <p style="text-align: centre;">New to online sevices??</p>
                <p style="font-size: 16px; text-align: centre;"><a href="#">Create A New Account</a></p></td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-4">
    <form>
      <fieldset>
        <legend>Welcome Laboratorist</legend>
        <table width="406" height="238">
          <tbody>
            <tr>
              <td width="170" height="68"><label>laboratorist id:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="29"><label>Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="122">&nbsp;</td>
              <td><input type="submit" />
                <br />
                <p style="text-align: centre;">New to online sevices??</p>
                <p style="font-size: 16px; text-align: centre;"><a href="#">Create A New Account</a></p></td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
  <div id="tabs-6">
   <form>
      <fieldset>
        <legend>Welcome Admin</legend>
        <table width="406" height="238">
          <tbody>
            <tr>
              <td width="170" height="68"><label>admin id:</label></td>
              <td width="224"><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="29"><label>Password:</label></td>
              <td><input type="text" name="textfield" id="textfield" /></td>
            </tr>
            <tr>
              <td height="122">&nbsp;</td>
              <td><input type="submit" />
                <br />
                <p style="text-align: centre;">New to online sevices??</p>
                <p style="font-size: 16px; text-align: centre;"><a href="#">Create A New Account</a></p></td>
            </tr>
          </tbody>
        </table>
      </fieldset>
    </form>
  </div>
</div>
</div>
<script type="text/javascript">
$(function() {
	$( "#Tabs1" ).tabs(); 
});
</script>
</body>
</html>