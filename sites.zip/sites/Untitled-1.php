<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="navmenu.css" rel="stylesheet" type="text/css">
</head>

<body>
<nav id="nav">
  <ul>
    <li><a href="index.php">home </a>
      <ul><li><a href="index.php">list1</a></li>
        <li><a href="index.php">list2</a></li>
        <li><a href="index.php">list3</a></li>
        <li><a href="index.php">list4</a></li>
    </ul></li>
    <li><a href="index.php">home </a>
      <ul><li><a href="index.php">list1</a></li>
        <li><a href="index.php">list2</a></li>
        <li><a href="index.php">list3</a></li>
        <li><a href="index.php">list4</a></li>
    </ul></li>
    <li><a href="index.php">home </a>
      <ul><li><a href="index.php">list1</a></li>
        <li><a href="index.php">list2</a></li>
        <li><a href="index.php">list3</a></li>
        <li><a href="index.php">list4</a></li>
    </ul></li>
    <li><a href="index.php">home </a>
      <ul><li><a href="index.php">list1</a></li>
        <li><a href="index.php">list2</a></li>
        <li><a href="index.php">list3</a></li>
        <li><a href="index.php">list4</a></li>
    </ul></li>
  </ul>
</nav>
</body>
</html>