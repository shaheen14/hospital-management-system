<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/finalemployees.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Untitled Document</title>
<!-- InstanceEndEditable -->
<style type="text/css">
#t_container {
	height: 685px;
	width: 100%;
	margin-top: -9px;
	margin-right: -9px;
	margin-bottom: -9px;
	margin-left: -9px;
}
#t_container #upper {
	width: 102%;
	height: 80px;
	background-color: #52D3AD;
	margin-top: 0px;
	color: #000000;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-weight: 600;
	text-transform: uppercase;
	text-align: center;
	text-shadow: 0px 0px;
	letter-spacing: 5px;
	word-spacing: 8px;
}
#t_container #main_content {
	width: 100%;
	height: 530px;
	float: left;
}
#t_container #main_content #left_menuside {
	width: 20%;
	float: left;
	height: 400px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	padding: 0px;
	margin-left: 0px;
	background-color: #56D9BF;
}
#main_content #left_menuside ul {
	padding: 0px;
	margin: 0px;
	width: 100%;
}
#left_menuside ul li {
	list-style: none;
	background-color: #8AD3BD;
	text-indent: 6px;
	border: 1px solid #EAEDEC;
	width: 100%;
	height: 48px;
}
#left_menuside ul li a {
	text-decoration: none;
	color: #050505;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	text-transform: uppercase;
	width: 193px;
	height: 54px;
	display: block;
	text-align: center;
	line-height: 45px;
}
#left_menuside ul li:hover ul {
	visibility: visible;
	top: 31px;
}
#left_menuside ul li a:hover {
	color: #D5D0AF;
}
#t_container #main_content #right_content {
	width: 75%;
	height: 400px;
	float: left;
}

#t_container #lower {
	clear: both;
	width: 100%;
	height: 60px;
	text-align: center;
	color: #000000;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-style: normal;
	font-weight: 600;
}
</style>
<!-- InstanceBeginEditable name="head" -->
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
<!-- InstanceEndEditable -->
</head>

<body>
<div id="t_container">
  <header id="upper"><br />
    <!-- InstanceBeginEditable name="edit_text" -->
    <h3>welcome to accountant portal</h3>
  <!-- InstanceEndEditable --></header>
  <main id="main_content"><aside id="left_menuside"><!-- InstanceBeginEditable name="Edit_menu" -->
    <ul>
      <li><a href="#">manage invoice </a></li>
      <li><a href="#"> manage charges</a></li>
      <li><a href="#">manage payment</a></li>
      <li><a href="#">profile</a></li>
    </ul>
  <!-- InstanceEndEditable --></aside>
    <!-- InstanceBeginEditable name="Edit_content" --><!-- TemplateBeginEditable name="Edit_accontant_cont" -->
    <aside id="right_content"></aside>
    <!-- TemplateEndEditable --><!-- InstanceEndEditable --></main>
  <footer id="lower">For any help -contact to admin at 8969420647<br />
    All rights reserved @ admin 
  </footer>
</div>


</body>
<!-- InstanceEnd --></html>
