/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};
var opts = {};
var resources = [
];
var symbols = {
"stage": {
    version: "3.0.0",
    minimumCompatibleVersion: "3.0.0",
    build: "3.0.0.322",
    baseState: "Base State",
    scaleToFit: "none",
    centerStage: "none",
    initialState: "Base State",
    gpuAccelerate: false,
    resizeInstances: false,
    content: {
            dom: [
            {
                id: 'patient_portal_Max_Width_320_Max_Height_240',
                type: 'image',
                rect: ['0', '0','500px','223px','auto', 'auto'],
                fill: ["rgba(0,0,0,0)",im+"patient%20portal%20%5BMax%20Width%20320%20Max%20Height%20240%5D.jpg",'0px','0px']
            },
            {
                id: 'hospital-mangement1_Max_Width_320_Max_Height_240',
                type: 'image',
                rect: ['0', '0','500px','223px','auto', 'auto'],
                fill: ["rgba(0,0,0,0)",im+"hospital-mangement1%20%5BMax%20Width%20320%20Max%20Height%20240%5D.jpg",'0px','0px']
            },
            {
                id: 'hospital-logo_6_Max_Width_320_Max_Height_240',
                type: 'image',
                rect: ['0', '0','500px','223px','auto', 'auto'],
                fill: ["rgba(0,0,0,0)",im+"hospital-logo%20%286%29%20%5BMax%20Width%20320%20Max%20Height%20240%5D.jpg",'0px','0px']
            },
            {
                id: 'hospital_Max_Width_320_Max_Height_240',
                type: 'image',
                rect: ['0', '0','500px','223px','auto', 'auto'],
                fill: ["rgba(0,0,0,0)",im+"hospital%20%5BMax%20Width%20320%20Max%20Height%20240%5D.jpg",'0px','0px']
            },
            {
                id: 'hospital_management_Max_Width_320_Max_Height_240',
                type: 'image',
                rect: ['0', '0','500px','223px','auto', 'auto'],
                fill: ["rgba(0,0,0,0)",im+"hospital%20management%20%5BMax%20Width%20320%20Max%20Height%20240%5D.jpg",'0px','0px']
            }],
            symbolInstances: [

            ]
        },
    states: {
        "Base State": {
            "${_patient_portal_Max_Width_320_Max_Height_240}": [
                ["style", "height", '300px'],
                ["style", "opacity", '1'],
                ["style", "width", '500px']
            ],
            "${_hospital-mangement1_Max_Width_320_Max_Height_240}": [
                ["style", "height", '300px'],
                ["style", "opacity", '1'],
                ["style", "width", '500px']
            ],
            "${_hospital-logo_6_Max_Width_320_Max_Height_240}": [
                ["style", "height", '300px'],
                ["style", "opacity", '1'],
                ["style", "width", '500px']
            ],
            "${_Stage}": [
                ["color", "background-color", 'rgba(255,255,255,1)'],
                ["style", "overflow", 'hidden'],
                ["style", "height", '300px'],
                ["style", "width", '500px']
            ],
            "${_hospital_management_Max_Width_320_Max_Height_240}": [
                ["style", "height", '300px'],
                ["style", "opacity", '1'],
                ["style", "width", '500px']
            ],
            "${_hospital_Max_Width_320_Max_Height_240}": [
                ["style", "height", '300px'],
                ["style", "opacity", '1'],
                ["style", "width", '500px']
            ]
        }
    },
    timelines: {
        "Default Timeline": {
            fromState: "Base State",
            toState: "",
            duration: 16500,
            autoPlay: true,
            labels: {
                "Label 1": 0
            },
            timeline: [
                { id: "eid32", tween: [ "style", "${_patient_portal_Max_Width_320_Max_Height_240}", "opacity", '1', { fromValue: '1'}], position: 12000, duration: 0 },
                { id: "eid34", tween: [ "style", "${_patient_portal_Max_Width_320_Max_Height_240}", "opacity", '0', { fromValue: '1'}], position: 14000, duration: 2500 },
                { id: "eid23", tween: [ "style", "${_hospital-logo_6_Max_Width_320_Max_Height_240}", "opacity", '1', { fromValue: '1'}], position: 6000, duration: 0 },
                { id: "eid25", tween: [ "style", "${_hospital-logo_6_Max_Width_320_Max_Height_240}", "opacity", '0', { fromValue: '1'}], position: 7000, duration: 1500 },
                { id: "eid26", tween: [ "style", "${_hospital-mangement1_Max_Width_320_Max_Height_240}", "opacity", '1', { fromValue: '1'}], position: 8500, duration: 0 },
                { id: "eid31", tween: [ "style", "${_hospital-mangement1_Max_Width_320_Max_Height_240}", "opacity", '0', { fromValue: '1'}], position: 10000, duration: 2000 },
                { id: "eid17", tween: [ "style", "${_hospital_management_Max_Width_320_Max_Height_240}", "opacity", '0', { fromValue: '1'}], position: 1000, duration: 2000 },
                { id: "eid22", tween: [ "style", "${_hospital_Max_Width_320_Max_Height_240}", "opacity", '0', { fromValue: '1'}], position: 4250, duration: 1750 },
                { id: "eid36", tween: [ "style", "${_hospital_Max_Width_320_Max_Height_240}", "height", '300px', { fromValue: '300px'}], position: 0, duration: 0 },
                { id: "eid35", tween: [ "style", "${_hospital_management_Max_Width_320_Max_Height_240}", "height", '300px', { fromValue: '300px'}], position: 0, duration: 0 },
                { id: "eid38", tween: [ "style", "${_hospital-mangement1_Max_Width_320_Max_Height_240}", "height", '300px', { fromValue: '300px'}], position: 0, duration: 0 },
                { id: "eid37", tween: [ "style", "${_hospital-logo_6_Max_Width_320_Max_Height_240}", "height", '300px', { fromValue: '300px'}], position: 0, duration: 0 },
                { id: "eid39", tween: [ "style", "${_patient_portal_Max_Width_320_Max_Height_240}", "height", '300px', { fromValue: '300px'}], position: 0, duration: 0 }            ]
        }
    }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources, opts);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-25816401");
