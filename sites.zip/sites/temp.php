<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/finalnew.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Untitled Document</title>
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css" />
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css" />
<link href="jQueryAssets/jquery.ui.tabs.min.css" rel="stylesheet" type="text/css" />
<script src="jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery-ui-1.9.2.tabs.custom.min.js" type="text/javascript"></script>
<style type="text/css">
#container #main #job_tab {
	width: 100%;
	height: 400px;
	float: left;
	text-align: left;
}
#job_tab ul {
	width: 170px;
	height: 240px;
	float: left;
	margin-top: 35px;
}
#job_tab ul li {
	width: 165px;
}
#job_tab table {
	float: left;
}
</style>
<link href="form_table.css" rel="stylesheet" type="text/css" />
<!-- InstanceEndEditable -->
<style type="text/css">
#container {
	height: 646px;
	width: 1090px;
	z-index: -1;
	opacity: 1;
	margin-right: auto;
	margin-left: auto;
	margin-top: 14px;
	top: 0px;
	bottom: 0px;
}
#container #top {
	width: 100%;
	height: 133px;
}
#top #twrapper #left {
	float: left;
	width: 225px;
	height: 129px;
}
#twrapper #left img {
	margin-top: 46px;
}
#top #twrapper #mid {
	float: left;
	width: 405px;
	height: 129px;
}
#twrapper #mid img {
}
#top #twrapper #middle {
	float: left;
	width: 171px;
	height: 129px;
	text-align: center;
}
#top #twrapper #right {
	float: left;
	width: 275px;
	height: 129px;
}
#nav {
	background-color: #8AD3BD;
	border-radius: 71px;
	height: 42px;
	padding-top: 0px;
	padding-right: 15px;
	padding-bottom: 0px;
	padding-left: 15px;
	width: 996px;
	margin-left: 30px;
	margin-right: 15px;
}
#nav ul {
	margin: 0px;
	padding: 0px;
	list-style-type: none;
}
#nav ul li {
	float: left;
	position: relative;
	list-style: none;
	background-color: #8AD3BD;
	text-indent: 0px;
	text-align: left;
	border: 1px solid #EAEDEC;
}
#nav ul li a {
	text-decoration: none;
	color: #050505;
	font-family: aladdin;
	text-transform: uppercase;
	width: 247px;
	height: 40px;
	display: block;
	line-height: 30px;
	text-align: center;
	
}
#nav ul  ul {
	position: absolute;
	visibility: hidden;
}
#nav ul li:hover ul {
	visibility: visible;
	top: 31px;
	
}
#nav ul li ul li a:hover {
	color: #77943F;
	background-color: #B7ADAD;
}
#nav ul li ul li a:hover {
	color: #77943F;
	background-color: #B7ADAD;
}
#nav ul li a:hover {
	color: #D5D0AF;
}
#nav ul li a#onlink
{
	background-color: #D75052;
}
#container #main {
	width: 100%;
	height: 420px;
}
#container #main #sidebar1 {
	width: 335px;
	height: 420px;
	float: left;
	font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif;
	font-size: 15px;
	color: #CC667C;
	font-style: normal;
	text-align: justify;
}
#main #sidebar1 h3 {
	font-weight: 400;
	font-size: 20px;
	font-family: Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	color: #050505;
	text-transform: capitalize;
	text-align: center;
}
#main #sidebar1 h5 {
	font-style: normal;
	font-weight: 400;
	color: #CC6D84;
	text-align: center;
	margin-top: 9px;
}
#main #sidebar1 ul {
	list-style-type: none;
	color: #050505;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-size: 18px;
	font-style: normal;
	text-align: center;
	font-weight: 400;
	margin-top: -8px;
	padding-top: 5px;
	padding-right: 5px;
	padding-bottom: 5px;
	padding-left: 5px;
}
#container #main #mainarea {
	width: 235px;
	height: 420px;
	text-align: left;
	float: left;
}
#mainarea h5 img {
	margin-top: 40px;
}
#mainarea h5 input {
	background-color: #8A92D3;
	width: 223px;
	height: 36px;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	border-radius: 36px;
	text-transform: capitalize;
	border-style: groove;
	font-size: 14px;
	display: block;
}
#container #main #sidebar2 {
	float: left;
	width: 520px;
	height: 420px;
}
#main #sidebar2 #EdgeID {
	margin-top: 35px;
}
#container #bottom {
	clear: both;
	height: 40px;
	width: 100%;
}
body {
	width: 100%;
	height: 650px;
}
#twrapper #right img {
	float: left;
}
#bottom ul li {
	float: left;
	list-style-type: none;
	text-align: center;
	text-indent: 20px;
	margin-right: auto;
	margin-left: auto;
}
 #bottom ul li a {
	color: #8AD3BD;
	list-style-type: none;
	text-decoration: none;
}
 #bottom ul li a:hover {
	visibility: visible;
	text-decoration: underline;
}
</style>
</head>
<body>
<div id="container">
  <header id="top">
    <div id="twrapper">
      <aside id="left"><img src="images/1135996.gif" width="219" height="76" alt=""/></aside>
      <main id="mid"><img src="images/emergency-hospital-building-17898688.jpg" width="405" height="132" alt=""/></main>
       <article id="middle">
        <p><a href="find_doctor.php">find a doctor</a></p>
        <p><a href="webappointment.php">web-appointment</a></p>
        <p><a href="job_search.php">find a job</a>         
      </p>
      </article>
      <aside id="right"><img src="images/We-care-about-YOU%20(2).jpg" width="269" height="129" alt=""/></aside>
    </div>
  </header>
  <nav id="nav">
   <ul>
    <li><a href="indexmain.php" target="_self">home </a>
    </li>
    <li><a href="#">Patient Corner </a>
      <ul>
        <li><a href="webappointment.php">web appointment</a></li>
        <li><a href="find_doctor.php">find a doctor</a></li>
        <li><a href="#">blood bank</a></li>
        <li><a href="patient/patient_login.php">inpatient account</a></li>
    </ul></li>
    <li><a href="indexmain.php">hospital system</a>
      <ul>
        <li><a href="job_search.php">find a job</a></li>
        <li><a href="about_us.php">about us</a></li>
        <li><a href="contact_us.php">contact us</a></li>
       
    </ul></li>
    <li><a href="indexmain.php">query</a>
      <ul>
        <li><a href="feedback_form.php">feedback form</a></li>
        <li><a href="#">faq</a></li>
    </ul></li>
  </ul>
  </nav>
  <!-- InstanceBeginEditable name="EditRegion2" -->
  <main id="main">
    <div id="job_tab">
      <ul>
        <li><a href="#tabs-1">See vacancies</a></li>
        <li><a href="#tabs-2">post resume</a></li>
</ul>
      <div id="tabs-1">
        
      </div>
      <div id="tabs-2">
        <form><table width="540" border="0" summary="job_resume">
  <caption>
    apply for job !!<br /><hr />
  </caption>
  <tbody>
    <tr>
      <th width="255" scope="col"><label>full name</label></th>
      <th width="275" scope="col">
        <input type="text" name="textfield" id="textfield" /></th>
    </tr>
    <tr>
      <td><label>name for the post</label></td>
      <td>
        <input type="text" name="textfield2" id="textfield2" /></td>
    </tr>
    <tr>
      <td><label>expected salary</label></td>
      <td>
      
      <input type="range" />
      </tr>
    <tr>
      <td><label>upload resume file</label></td>
      <td>
        <input type="file" name="fileField" id="fileField" /></td>
    </tr>
    <tr>
      <td height="113"><label></label></td>
      <td>&nbsp;<input name="submit" type="submit" id="submit" /></td>
    </tr>
  </tbody>
</table>
</form>
      </div>
</div>
    
  </main>
  <script type="text/javascript">
$(function() {
	$( "#job_tab" ).tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
	$( "#Tabs1 li" ).removeClass( "ui-corner-top" ).addClass( "ui-corner-left" ); 
});
  </script>

  <!-- InstanceEndEditable -->
  <footer id="bottom"><ul> <li>Site map-</li>
   <li><a href="#">
     find a doctor
   </a></li>
   <li><a href="webappointment.php">request an appointment</a></li>
   <li><a href="patient/patient_login.php">see your reports</a></li>
   <li><a href="find_doctor.php">search job</a></li><li><a href="">view blood bank</a></li>
   <li><a href="about_us.php">about us</a></li>
   <li><a href="contact_us.php">contact us</a></li>
   <li><a href="indexmain.php">home</a></li>
   </ul></footer>
</div>

</body>
<!-- InstanceEnd --></html>