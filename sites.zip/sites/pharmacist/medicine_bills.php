<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/pharmacist_portal.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Untitled Document</title>
<link href="../jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css" />
<link href="../jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css" />
<link href="../jQueryAssets/jquery.ui.tabs.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#profile_tab ul {
	width: 85%;
}
#profile_tab ul li {
	width: 200px;
}
tr td select {
	width: 130px;
}
</style>

<!-- InstanceEndEditable -->
<style type="text/css">
#t_container {
	height: 685px;
	width: 100%;
	margin-top: -9px;
	margin-right: -9px;
	margin-bottom: -9px;
	margin-left: -9px;
}
#t_container #upper {
	width: 102%;
	height: 80px;
	background-color: #52D3AD;
	margin-top: 0px;
	color: #000000;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-weight: 600;
	text-transform: uppercase;
	text-align: center;
	text-shadow: 0px 0px;
	letter-spacing: 5px;
	word-spacing: 8px;
}
#t_container #main_content {
	width: 100%;
	height: 530px;
	float: left;
}
#t_container #main_content #left_menuside {
	width: 20%;
	float: left;
	height: 400px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	padding: 0px;
	margin-left: 0px;
	background-color: #56D9BF;
}
#main_content #left_menuside ul {
	padding: 0px;
	margin: 0px;
	width: 100%;
}
#left_menuside ul li {
	list-style: none;
	background-color: #8AD3BD;
	text-indent: 6px;
	border: 1px solid #EAEDEC;
	width: 100%;
	height: 48px;
}
#left_menuside ul li a {
	text-decoration: none;
	color: #050505;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	text-transform: uppercase;
	width: 193px;
	height: 54px;
	display: block;
	text-align: center;
	line-height: 45px;
}
#left_menuside ul li:hover ul {
	visibility: visible;
	top: 31px;
}
#left_menuside ul li a:hover {
	color: #D5D0AF;
}
#t_container #main_content #right_content {
	width: 75%;
	height: 400px;
	float: left;
}

#t_container #lower {
	clear: both;
	width: 100%;
	height: 60px;
	text-align: center;
	color: #000000;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-style: normal;
	font-weight: 600;
}
</style>

<!-- InstanceBeginEditable name="head" -->
<script src="../jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="../jQueryAssets/jquery-ui-1.9.2.tabs.custom.min.js" type="text/javascript"></script>
<!-- InstanceEndEditable -->

</head>

<body>
<div id="t_container">
  <header id="upper"><br />
    <!-- InstanceBeginEditable name="edit_text" -->
    <h3>welcome to Pharmacist portal</h3>
  <!-- InstanceEndEditable --></header>
  <main id="main_content"><aside id="left_menuside"><!-- InstanceBeginEditable name="Edit_menu" -->
    <ul>
      <li><a href="#">medicine category </a></li>
      <li><a href="#">manage medicine </a></li>
     <li><a href="#">medicine bills </a></li>
      <li><a href="#">profile </a></li>
    </ul>
  <!-- InstanceEndEditable --></aside>
    <!-- InstanceBeginEditable name="Edit_pharm_content" -->
    <aside id="right_content">
      <div id="profile_tab">
        <ul>
          <li><a href="#tabs-1">view bills list</a></li>
          <li><a href="#tabs-2">add medicines bills</a></li>
</ul>
        <div id="tabs-1">
          <p>Content 1</p>
        </div>
        <div id="tabs-2">
          <form>
          <table width="665" height="311" border="0">
  
  <tbody>
    <tr>
      <th width="31" scope="col"></th>
      <th width="136" scope="col"><label>medicine name</label></th>
      <th width="144" scope="col">rate</th>
      <th width="151" scope="col">qnty</th>
      <th width="154" scope="col">total</th>
    </tr>
    <tr>
      <td height="24"><label>1.</label></td>
      <td><select></select></td>
      <td><input type="text" /></td>
      <td><input type="number" name="number" id="number" /></td>
     <td><input type="text" /></td>
    </tr>
    <tr>
      <td height="24"><label>2.</label></td>
      <td><select></select></td>
     <td><input type="text" /></td>
      <td><input type="number" name="number" id="number" /></td>
     <td><input type="text" /></td>
    </tr>
    <tr>
      <td height="24"><label>3.</label></td>
       <td><select></select></td>
     <td><input type="text" /></td>
     <td><input type="number" name="number" id="number" /></td>
      <td><input type="text" /></td>
    </tr>
    <tr>
      <td height="24"><label>4.</label></td>
      <td><select></select></td>
     <td><input type="text" /></td>
      <td><input type="number" name="number" id="number" /></td>
      <td><input type="text" /></td>
    </tr>
    <tr>
      <td height="24"><label>5.</label></td>
      <td><select></select></td>
     <td><input type="text" /></td>
     <td><input type="number" name="number" id="number" /></td>
     <td><input type="text" /></td>
    </tr>
    <tr>
      <td height="24"><label>6.</label></td>
      <td><select></select></td>
     <td><input type="text" /></td>
     <td><input type="number" name="number" id="number" /></td>
      <td><input type="text" /></td>
    </tr>
    <tr>
      <td height="24"><label>7.</label></td>
      <td><select></select></td>
     <td><input type="text" /></td>
     <td><input type="number" name="number" id="number" /></td>
      <td><input type="text" /></td>
    </tr>
    <tr>
      <td><label>8.</label></td>
      <td><select></select></td>
     <td><input type="text" /></td>
    <td><input type="number" name="number" id="number" /></td>
      <td><input type="text" /></td>
    </tr>
    <tr>
      <td height="24"><label>9.</label></td>
      <td><select></select></td>
      <td><input type="text" /></td>
      <td><input type="number" name="number" id="number" /></td>
      <td>
        <input type="text" name="textfield2" id="textfield2" /></td>
    </tr>
    <tr>
      <td height="24"><label>10.</label></td>
      <td><select></select></td>
     <td><input type="text" /></td>
     <td><input type="number" name="number" id="number" /></td>
      <td>
        <input type="text" name="textfield" id="textfield" /></td>
    </tr>
    <tr>
      <td height="24">&nbsp;</td>
      <td><label>patient id</label></td>
      <td><input type="text" /></td>
      <td><label>total</label></td>
      <td><input type="text" /></td>
    </tr>
  </tbody>
</table>
          <p>&nbsp;</p>

          </form>
        </div>
</div>
    </aside>
    <script type="text/javascript">
$(function() {
	$( "#profile_tab" ).tabs(); 
});
    </script>
  <!-- InstanceEndEditable --></main>
  <footer id="lower">For any help -contact to admin at 8969420647<br />
    All rights reserved @ admin 
  </footer>
</div>


</body>
<!-- InstanceEnd --></html>
