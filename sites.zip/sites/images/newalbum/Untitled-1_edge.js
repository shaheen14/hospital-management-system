/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};
var opts = {};
var resources = [
];
var symbols = {
"stage": {
    version: "3.0.0",
    minimumCompatibleVersion: "3.0.0",
    build: "3.0.0.322",
    baseState: "Base State",
    scaleToFit: "none",
    centerStage: "none",
    initialState: "Base State",
    gpuAccelerate: false,
    resizeInstances: false,
    content: {
            dom: [
            {
                id: 'medical-store-logo_Max_Width_640_Max_Height_480',
                type: 'image',
                rect: ['0px', '0px','640px','480px','auto', 'auto'],
                opacity: 0,
                fill: ["rgba(0,0,0,0)",im+"medical-store-logo%20%5BMax%20Width%20640%20Max%20Height%20480%5D.jpg",'0px','0px']
            },
            {
                id: 'red-cross-flag_Max_Width_640_Max_Height_4802',
                type: 'image',
                rect: ['0px', '0px','640px','480px','auto', 'auto'],
                opacity: 0,
                fill: ["rgba(0,0,0,0)",im+"red-cross-flag%20%5BMax%20Width%20640%20Max%20Height%20480%5D2.jpg",'0px','0px']
            },
            {
                id: 'hospital-logo_6_Max_Width_640_Max_Height_4802',
                type: 'image',
                rect: ['0px', '0px','640px','480px','auto', 'auto'],
                fill: ["rgba(0,0,0,0)",im+"hospital-logo%20%286%29%20%5BMax%20Width%20640%20Max%20Height%20480%5D2.jpg",'0px','0px']
            }],
            symbolInstances: [

            ]
        },
    states: {
        "Base State": {
            "${_Stage}": [
                ["color", "background-color", 'rgba(255,255,255,1)'],
                ["style", "width", '640px'],
                ["style", "height", '480px'],
                ["style", "overflow", 'hidden']
            ],
            "${_hospital-logo_6_Max_Width_640_Max_Height_4802}": [
                ["style", "top", '0px'],
                ["style", "opacity", '1'],
                ["style", "left", '0px'],
                ["style", "height", '480px']
            ],
            "${_red-cross-flag_Max_Width_640_Max_Height_4802}": [
                ["style", "top", '0px'],
                ["style", "height", '480px'],
                ["style", "opacity", '0'],
                ["style", "left", '0px'],
                ["style", "width", '640px']
            ],
            "${_medical-store-logo_Max_Width_640_Max_Height_480}": [
                ["style", "top", '0px'],
                ["style", "height", '480px'],
                ["style", "opacity", '0'],
                ["style", "left", '0px'],
                ["style", "width", '640px']
            ]
        }
    },
    timelines: {
        "Default Timeline": {
            fromState: "Base State",
            toState: "",
            duration: 35000,
            autoPlay: true,
            labels: {
                "Label 1": 0
            },
            timeline: [
                { id: "eid71", tween: [ "style", "${_medical-store-logo_Max_Width_640_Max_Height_480}", "opacity", '1', { fromValue: '0'}], position: 15000, duration: 10000 },
                { id: "eid67", tween: [ "style", "${_medical-store-logo_Max_Width_640_Max_Height_480}", "opacity", '0', { fromValue: '1'}], position: 25000, duration: 10000 },
                { id: "eid70", tween: [ "style", "${_red-cross-flag_Max_Width_640_Max_Height_4802}", "opacity", '1', { fromValue: '0'}], position: 5000, duration: 10000 },
                { id: "eid65", tween: [ "style", "${_red-cross-flag_Max_Width_640_Max_Height_4802}", "opacity", '0', { fromValue: '1'}], position: 15000, duration: 10000 },
                { id: "eid68", tween: [ "style", "${_red-cross-flag_Max_Width_640_Max_Height_4802}", "opacity", '0', { fromValue: '0.000000'}], position: 25000, duration: 10000 },
                { id: "eid59", tween: [ "style", "${_hospital-logo_6_Max_Width_640_Max_Height_4802}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
                { id: "eid61", tween: [ "style", "${_hospital-logo_6_Max_Width_640_Max_Height_4802}", "opacity", '0', { fromValue: '1'}], position: 2485, duration: 5000 }            ]
        }
    }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources, opts);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-14713063");
